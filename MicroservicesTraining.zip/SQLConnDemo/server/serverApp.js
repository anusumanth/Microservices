/**
 * http://usejsdoc.org/
 */
var express        =         require("express");
var bodyParser     =         require("body-parser");
var mysql          =         require('mysql');
var app            =         express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'rps@123',
    database : 'anzfinancedb'
});

app.post('/login',function(req,res){

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    var user_name=req.body.userName;
    var password=req.body.password;
    console.log(req.body);
    console.log("User name = "+user_name+", password is "+password);
    //console.log(req.body);
    res.end("done");


});

app.post('/Registration',function(req,res){

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
    connection.connect();
    var insertRow = 'INSERT INTO customer (CUSTOMER_ID,name,address,mobile_no) VALUE(?,?,?,?)';
    connection.query(insertRow,[req.body.customerid,req.body.name,req.body.address, req.body.mobileno], function(err, rows, fields) {
        if (!err)
            console.log('inserted data is: ', rows);
        else
            console.log('Error while performing Query.');
    });
    connection.end();
    console.log(req.body);
    //console.log(req.body);
    res.end("done");


});
app.listen(6161,function(){
    console.log("Started on PORT 6161");
})