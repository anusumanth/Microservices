package com.anz.banking.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Transaction {
	private int transactionId;
	private int amount;
	@Autowired
	@Qualifier("dc2")
	private DebitCard debitCard;
	
	public void setDebitCard(DebitCard debitCard) {
		this.debitCard = debitCard;
	}
	public Transaction(int transactionId, int amount){
		super();
		this.transactionId 	= transactionId;
		this.amount			= amount;
		
	}	
	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public DebitCard getDebitCard() {
		return debitCard;
	}
}