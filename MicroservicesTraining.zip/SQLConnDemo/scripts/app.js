$(document).ready(function()
{
	console.log("I am ready !@!!")
	//alert("testing....");
    $("#submit").click(function()
    {
      //alert("form submitted");
      user=$("#userName").val();
        pwd=$("#password").val();
        alert(user+pwd);
                data={
            "userName":user,
            "password":pwd
        }
        $.post("http://localhost:6161/login",data, function(data){
            if(data==='done')
            {
                console.log("login Successful");
            }
            console.log(data);
        });

    })
})