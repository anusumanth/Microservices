/**
 * 
 */
console.log("Happy Gowri & Ganesha !!!!!");

customerObject = new Object();
customerObject.ID = 34262829
customerObject.Name = "RPS"

console.log(customerObject);

//method2

obj = {
		ID: 23454566,
		Name: "RPS",
		dob: new Date(1984,25,9),
		address:{
			streetName: "Richmond Road",
			city: "Bangalore",
			geo: {
				lat:"88.33",
				long: "12.87"	
			}
				
		} 
}
console.log(obj);
console.log(obj.address.geo);
console.log(obj.address.geo.lat);
console.log(obj.address.geo.long);
//console.log ("**********************************************************");
var fs = require('fs');
var obj;
fs.readFile('Users.js', 'utf8', function (err, data) {
  if (err) throw err;
  obj = JSON.parse(data);
  
  for (pos in obj)
	  {
	  	if(pos <5)
	  		{
	  			console.log(obj[pos].name);
	  			console.log(obj[pos].address.geo.lat);	 			
	  			
	  		}
	  }
  
}); 
//method 3
function Member(name, type)
{
	this.name = name;
	this.type = type;
}
obj = new Member("RPS", "Training");
console.log("*****************Method 3**************************")
console.log(obj);

Member.prototype.display=function()
{
	console.log(this.name, '\t', this.type)
}
console.log("*****************Method 3.1**************************")
obj.display();


//inheritance


