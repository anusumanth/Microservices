/**
 * http://usejsdoc.org/
 */
var mysql      = require('mysql');
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'rps@123',
    database : 'anzfinancedb'
});

connection.connect();



var insertRow = 'INSERT INTO customer (CUSTOMER_ID,name,address,mobile_no) VALUE(?,?,?,?)';
connection.query(insertRow,[null,'ANZ User 4','Melbourne','+6186554784'], function(err, rows, fields) {
    if (!err)
        console.log('The solution is: ', rows);
    else
        console.log('Error while performing Query.');
});

connection.query('SELECT * from customer', function(err, rows, fields) {
    if (!err)
        console.log('The solution is: ', rows);
    else
        console.log('Error while performing Query.');
});

connection.end();