/**
 * http://usejsdoc.org/
 */
var fs = require('fs');
var obj;
fs.readFile('Users.json', function (err, data) {
  if (err) {
	  console.error(err);
  }
  obj = JSON.parse(data);
  
  for (pos in obj)
	  {
	  	if(pos <5)
	  		{
	  			console.log(obj[pos].name);
	  			console.log(obj[pos].address.geo.lat);	 			
	  			
	  		}
	  }
  
});