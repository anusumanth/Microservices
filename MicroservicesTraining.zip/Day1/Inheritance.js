/**
 * http://usejsdoc.org/
 */
function Person(name, address)
{
	this.Name = name;
	this.Address = address;
}


function Member(name,address,type)
{
	Person.call(this,name,address);
	this.Type = type;
}

function President(name, address,type,resp)
{
	Member.call(this,name,address,type);
	this.Responsibility = resp;
}

Member.prototype 		= new Person();
President.prototype		= new Member();

obj = new President("Ramnath Kovind", "New Delhi","Gold", "Head of Armed Forces");
console.log(obj);
console.log(obj.Address);
console.log(obj.Responsibility);


