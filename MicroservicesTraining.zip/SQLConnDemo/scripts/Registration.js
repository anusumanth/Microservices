$(document).ready(function()
{
	console.log("I am ready !@!!")
	//alert("testing....");
    $("#submit").click(function()
    {
      //alert("form submitted");
      id=$("#customerid").val();
      name=$("#name").val();
      address=$("#address").val();
      mobile=$("#mobileno").val();        
      alert("Customer Data Submitted!!!");
      data={
            "customerId":id,
            "name":name,
            "address":address,
            "Mobile_No":mobile
        }
        $.post("http://localhost:6161/Registration",data, function(data){
            if(data==='done')
            {
                console.log("User Data Submitted!!!!");
                alert("Data Submitted Successfully");
            }
            console.log(data);
        });

    })
})