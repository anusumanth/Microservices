package com.anz.services;

import com.anz.models.Customer;

public interface CustomerService {

	void addCustomerData(Customer customer);
}
