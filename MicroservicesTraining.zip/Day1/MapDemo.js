/**
 * http://usejsdoc.org/
 */
customMap = new Map ([
            ["ID", 434566],
            ["Name", "RPS"]
                      
                      
]);
customMap.set("address","Bangalore")
console.log(customMap);

for(var key in customMap.keys()) {
	console.log(key);
}

for(var key in customMap.values()) {
	console.log(value);
}
