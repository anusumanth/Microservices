package com.anz.ecommerce.MircroServicesDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MircroServicesDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MircroServicesDemoApplication.class, args);
	}
}
