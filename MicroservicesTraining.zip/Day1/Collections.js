/**
 * http://usejsdoc.org/
 */
Data =[];
Data.push(1);
Data.push("Happy");
Data.push("Gowri");
Data.push("Ganesha");
Data.push(492.22);
Data.push(-3464);

console.log(Data);

for(i=0;i<10;i++){
	
	Data.push(Math.floor(Math.random(i)*10)+1);
	
}

console.log(Data);

var result = Array.from("RPS Consulting");
console.log(result);

function isBigEnough(value)
{
	return value >=10;
}
var filtered =[12,5,8,120,44].filter(isBigEnough)
console.log(filtered);

/// var args

restParam('IN','AU','GBR');
