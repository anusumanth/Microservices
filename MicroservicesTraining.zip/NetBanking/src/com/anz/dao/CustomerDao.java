package com.anz.dao;

import com.anz.models.Customer;

public interface CustomerDao {

	void addCustomer(Customer customer);
}
